OOP Java Assignment - Άρης Τσιλιφώνης 1115201700170

Compile commands:
1) javac Building.java Staircase.java Corridor.java oop3.java Floor.java GroundFloor.java Classroom.java Space.java Student.java Teacher.java
2) javac *.java     
Run: 
java oop3 3 5 2 5 8